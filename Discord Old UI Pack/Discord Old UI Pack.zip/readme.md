# DISCORD Old UI Pack!
![2021-05-17_18 32 28](https://user-images.githubusercontent.com/74849003/118477286-7c400c80-b749-11eb-87f8-802499d6c883.png)


## 特徴

・Discordをモチーフとしたカラー

・シンプルなUI

・シンプルなクリック音と通知音

・カスタムフォント

・色付きのロード画面

・他のリソースパックと組み合わせて使用可能

・絵文字をサポート

ボタンのカラーやフォントの変更などのリソースパック内のデータを改変するのは基本的にOKですが、改変したパックを配布するのはNGです。


## feature

・Colors with Discord as a motif

・Simple UI

・Simple Click Sound and Notification Sound

・Custom font

・Custom color loading screen

・Can be used in conjunction with other resource packs

・Support Emojis

It is basically OK to modify the data in the resource pack, such as changing the color or font of the buttons, but it is NG to distribute the modified pack.
